#-*- utf-8 -*-
import sys,base64,json,os,time,threading,screenshot
from PIL import Image,ImageEnhance
from aip import AipOcr
import getstring


app_id = '填你申请的百度识别id'                               
api_key= '填你申请的百度识别key'
secret_key= '填你申请的百度识别secretkey'

a = 0
b = 0
c = 0

def get_screenshot():
  screenshot.check_screenshot()
  screenshot.pull_screenshot()
  im = Image.open(r"./screenshot.png")    #导入手机截图  
  img_size = im.size
  w = im.size[0]
  # h = im.size[1]
  print("截图:{}".format(img_size))

  region = im.crop((70,300, w-70,1200))    #裁剪的区域,可以自己修改
  enh_con = ImageEnhance.Contrast(region)   
  image_contrasted = enh_con.enhance(1.5)
  image_contrasted.save("./crop_test1.png")

  
def get_question():
  global question,ch0,ch1,ch2
  
  f=open('./crop_test1.png','rb')
  image_data=f.read()

  client = AipOcr(app_id, api_key, secret_key)                #识别过程
  result = client.basicGeneral(image_data)
  if "error_code" in result:
      print("baidu api error: ", result["error_msg"])
  else:
      words_results = result['words_result']                  #得到识别结果的问题+选项
      #print (result['words_result'])   
  question = ''
  choice = ['','','','','','']
  num = 0
  choice_num = 0
  for words_result in words_results:
        num+=1
        if(num >=len(words_results)-2):
          choice[choice_num] = words_result['words']
          choice_num+=1
        else:
          question = question + words_result['words']
  ch0 = str(choice[0])
  ch1 = str(choice[1])
  ch2 = str(choice[2])
  print(question)       #打印问题
  print('  A:'+choice[0]+' B:'+choice[1]+' C:'+choice[2])       #打印选项
  
get_screenshot()
get_question()
ques='http://www.baidu.com/s?&wd=' +str(question)
cho0='http://www.baidu.com/s?&wd=' +str(ch0)
cho1='http://www.baidu.com/s?&wd=' +str(ch1)
cho2='http://www.baidu.com/s?&wd=' +str(ch2)

getstring.getstring(ques)
print(getstring.infostring)
print('----------------------------------------')

a = getstring.infostring.count(ch0.replace('A', ''))
b = getstring.infostring.count(ch1.replace('B', ''))
c = getstring.infostring.count(ch2.replace('C', ''))

print(' 选项    出现次数  ')
print('  A：     ' + str(a))
print('  B：     ' + str(b))
print('  C：     ' + str(c))
print('----------------------------------------')
d = getstring.getstring(cho0)
e = getstring.infostring.count(ch0.replace('A.', ''))
print(getstring.linkstr)
print(' 命题正确    出现次数  ')
print('  A：         ' + str(e))
print('----------------------------------------')
f = getstring.getstring(cho1)
g = getstring.infostring.count(ch1.replace('B.', ''))
print(getstring.linkstr)
print(' 命题正确    出现次数  ')
print('  B：         ' + str(g))
print('----------------------------------------')
g = getstring.getstring(cho2)
i = getstring.infostring.count(ch2.replace('C.', ''))
print(getstring.linkstr)
print(' 命题正确    出现次数  ')
print('  C：         ' + str(i))



