# -*- conding:utf-8 -*-
import requests
import re
import sys
from lxml import etree #lxml速度快百倍
from bs4 import BeautifulSoup

def getstring(url) : #百度问题/答案并爬取出中文内容
    global infostring,linkstr
    non_bmp_map = dict.fromkeys(range(0x10000, sys.maxunicode + 1), 0xfffd)#修正编码错误
    html=requests.get(url).text #打开网页
    soup = BeautifulSoup(html,"lxml") #soup装载
    for script in soup(["a"]):   
        script.extract()  #丢掉所有超链接
    link_=soup.find_all('div',attrs={"class":"result c-container "}) #爬取出所有abstract
    link=soup.find('div',attrs={"class":"c-abstract"})
    info = [] #构建空列表
    for item in link_:
        info.append(item.text) #自然连接字符串
    infostr="".join(info).strip() #去除非法格式
    infostring=str(infostr).encode('utf-8').decode().translate(non_bmp_map)#正式修正编码
    linkstr="".join(link.text).strip() #去除非法格式

    
#getstring('http://www.baidu.com/s?&wd=大泽乡起义中陈胜王"的字条是在哪里发现的')#测试用代码请无视
#print(infostring)#题目用
#print(linkstr)#答案用
